import React, { useState } from 'react'

const FORM_ENDPOINT = 'https://formspree.io/f/FORM_ACTION' // replace with your Formspree endpoint
const MAILTO_EMAIL = 'novalinkmedia@gmail.com' // business contact email

export default function App(){
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e){
    e.preventDefault()
    setSending(true); setError('')
    const form = new FormData(e.target)
    try{
      const res = await fetch(FORM_ENDPOINT, { method: 'POST', body: form })
      if(res.ok){ setSent(true) } else { setError('Failed to send — check your form endpoint.') }
    }catch(err){ setError('Network error — try again.') }
    setSending(false)
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 antialiased">
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-black text-white font-semibold">NL</div>
          <div>
            <a className="text-lg font-semibold">NovaLink Media</a>
            <p className="text-xs text-slate-500">Creating content that connects — powered by AI.</p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 pb-24">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center pt-8">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4">AI-powered content that grows brands — simple, modern, measurable.</h1>
            <p className="text-lg text-slate-600 mb-6">We combine human creativity with AI speed to deliver social content, short-form video, and strategy — made for global impact.</p>
            <div className="flex gap-3">
              <a href="#contact" className="px-5 py-3 rounded-md bg-black text-white text-sm font-medium">Start a project</a>
            </div>
            <div className="mt-6 text-sm text-slate-500">
              <strong>Free sample:</strong> DM 3 free posts for your page — no obligation.
            </div>
          </div>

          <div className="p-6 bg-slate-50 rounded-2xl">
            <div className="flex flex-col gap-4">
              <div className="rounded-md p-4 bg-white shadow">
                <h3 className="text-sm font-semibold">Starter</h3>
                <p className="text-xs text-slate-500">10 posts + captions</p>
                <div className="mt-3 text-2xl font-bold">R600</div>
              </div>
              <div className="rounded-md p-4 bg-white shadow">
                <h3 className="text-sm font-semibold">Pro</h3>
                <p className="text-xs text-slate-500">20 posts + 4 short videos</p>
                <div className="mt-3 text-2xl font-bold">R2,500</div>
              </div>
              <div className="rounded-md p-4 bg-white shadow">
                <h3 className="text-sm font-semibold">Elite</h3>
                <p className="text-xs text-slate-500">Full management</p>
                <div className="mt-3 text-2xl font-bold">R7,000</div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="mt-16">
          <h2 className="text-2xl font-bold mb-4">Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <article className="p-6 border rounded-lg">
              <h3 className="font-semibold mb-2">AI Branding</h3>
              <p className="text-sm text-slate-600">Fast brand assets using AI prompts and human polish.</p>
            </article>
            <article className="p-6 border rounded-lg">
              <h3 className="font-semibold mb-2">Social Automation</h3>
              <p className="text-sm text-slate-600">Scheduled posts, captions and short-form videos.</p>
            </article>
            <article className="p-6 border rounded-lg">
              <h3 className="font-semibold mb-2">Web Design</h3>
              <p className="text-sm text-slate-600">Modern landing pages and portfolio sites.</p>
            </article>
          </div>
        </section>

        <section id="about" className="mt-16">
          <h2 className="text-2xl font-bold mb-4">About</h2>
          <p className="text-sm text-slate-600">NovaLink Media helps brands scale their online presence using AI-first workflows and clean design.</p>
        </section>

        <section id="contact" className="mt-16 mb-24">
          <h2 className="text-2xl font-bold mb-4">Get in touch</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 border rounded-lg">
              <h3 className="font-semibold mb-2">Ready to grow?</h3>
              <p className="text-sm text-slate-600 mb-4">DM us on Instagram or fill the form — we’ll send 3 free sample posts to get started.</p>
              <ul className="text-sm text-slate-600 space-y-2">
                <li><strong>Instagram:</strong> @novalinkmedia</li>
                <li><strong>Email:</strong> <a href={`mailto:${MAILTO_EMAIL}`} className="underline">{MAILTO_EMAIL}</a></li>
                <li><strong>Location:</strong> Remote — global clients welcome</li>
              </ul>
            </div>

            <form onSubmit={handleSubmit} className="p-6 border rounded-lg" method="POST">
              <label className="block text-sm font-medium text-slate-700">Your name</label>
              <input name="name" required className="mt-2 mb-4 w-full p-3 border rounded" />

              <label className="block text-sm font-medium text-slate-700">Business / Instagram</label>
              <input name="business" required className="mt-2 mb-4 w-full p-3 border rounded" placeholder="@yourbusiness" />

              <label className="block text-sm font-medium text-slate-700">Message</label>
              <textarea name="message" rows="4" required className="mt-2 mb-4 w-full p-3 border rounded" placeholder="Tell us about your goals..."></textarea>

              <button type="submit" disabled={sending} className="w-full py-3 rounded-md bg-black text-white">{sending? 'Sending...' : 'Send message'}</button>

              {error && <p className="text-sm text-red-500 mt-3">{error}</p>}
              {sent && <p className="text-sm text-green-600 mt-3">Thanks — message sent. We’ll reply within 24 hours.</p>}

            </form>
          </div>
        </section>

        <footer className="py-12 text-center text-slate-500">
          © {new Date().getFullYear()} NovaLink Media — AI-Powered Content. All rights reserved.
          <div className="mt-3 text-xs">Built with free tools • Designed for scale</div>
        </footer>
      </main>
    </div>
  )
}
